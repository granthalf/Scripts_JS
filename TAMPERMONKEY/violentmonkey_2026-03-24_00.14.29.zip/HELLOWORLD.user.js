// ==UserScript==
// @name         HELLOWORLD
// @namespace    http://tampermonkey.net/
// @version      2026-03-04
// @description  try to take over the world!
// @author       GrantHalf
// @match        https://*/*
// @icon data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NDggNTEyIj48cGF0aCBmaWxsPSIjRDlBNjNBIiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjIwIiBkPSJNNDA4Ljc4MSAxMjguMDA3QzM4Ni4zNTYgMTI3LjU3OCAzNjggMTQ2LjM2IDM2OCAxNjguNzlWMjU2aC04Vjc5Ljc5YzAtMjIuNDMtMTguMzU2LTQxLjIxMi00MC43ODEtNDAuNzgzQzI5Ny40ODggMzkuNDIzIDI4MCA1Ny4xNjkgMjgwIDc5djE3N2gtOFY0MC43OUMyNzIgMTguMzYgMjUzLjY0NC0uNDIyIDIzMS4yMTkuMDA3IDIwOS40ODguNDIzIDE5MiAxOC4xNjkgMTkyIDQwdjIxNmgtOFY4MC43OWMwLTIyLjQzLTE4LjM1Ni00MS4yMTItNDAuNzgxLTQwLjc4M0MxMjEuNDg4IDQwLjQyMyAxMDQgNTguMTY5IDEwNCA4MHYyMzUuOTkybC0zMS42NDgtNDMuNTE5Yy0xMi45OTMtMTcuODY2LTM4LjAwOS0yMS44MTctNTUuODc3LTguODIzLTE3Ljg2NSAxMi45OTQtMjEuODE1IDM4LjAxLTguODIyIDU1Ljg3N2wxMjUuNjAxIDE3Mi43MDVBNDggNDggMCAwIDAgMTcyLjA3MyA1MTJoMTk3LjU5YzIyLjI3NCAwIDQxLjYyMi0xNS4zMjQgNDYuNzI0LTM3LjAwNmwyNi41MDgtMTEyLjY2YTE5Mi4wMTEgMTkyLjAxMSAwIDAgMCA1LjEwNC00My45NzVWMTY4Yy4wMDEtMjEuODMxLTE3LjQ4Ny0zOS41NzctMzkuMjE4LTM5Ljk5M3oiLz48L3N2Zz4=



// @grant        none
// ==/UserScript==

//Welcome on your first Script
(function() {alert('hello world');})();